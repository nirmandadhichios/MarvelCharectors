//
//  Date + Ext..swift
//  Marvel
//
//  Created by Nirman dadhich on 07/11/22.
//

import Foundation

extension Date {
    func getTimeIntervalSince1970() -> Int64 {
        return Int64(self.timeIntervalSince1970 * 1000)
    }
}
