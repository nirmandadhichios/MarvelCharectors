## Technology stack
> - MVVM architecture
> - UIKit
> - Alamofire 
> - SnapKit
> - Nuke
> - GCD
